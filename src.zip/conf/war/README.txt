These files are used only by the WAR version of Red5.
